#python -m pip install mysql-connector-python DONE
import mysql.connector
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="iamhappywithmylife",
  database="testdb"
)

print(mydb)

mycursor = mydb.cursor()
mycursor.execute("SHOW DATABASES")

for x in mycursor:
  print(x)
username1 ="sam"
password1="sam@123"
#mycursor.execute('SELECT * FROM accounts WHERE username = "sam" AND password = "sam@123" ')

mycursor.execute('SELECT * FROM accounts WHERE username = %s AND password = %s', (username1, password1))
#mycursor.execute('SELECT * FROM accounts WHERE username = username1 AND password = password1')

account = mycursor.fetchone()
if account:
    print('Logged in successfully !')
else:
    print('Invalid login credentials')
