# Referenece https://www.geeksforgeeks.org/flask-creating-first-simple-application/?ref=lbp
# Importing flask module in the project is mandatory
#TO CONTINUE WITH URL https://www.geeksforgeeks.org/login-and-registration-project-using-flask-and-mysql/
#Installed MySQL Insatller via software Center
from flask import Flask,request,render_template, redirect, url_for, session
from flask_mysqldb import MySQL
import mysql.connector
import MySQLdb.cursors
import re
# An object of Flask class is our WSGI application.
# Flask constructor takes the name of 
# current module (__name__) as argument.
app = Flask(__name__)   # Flask constructor 
app.secret_key = 'your secret key'
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="iamhappywithmylife",
  database="testdb"
)

print(mydb)

cursor = mydb.cursor()
#Only Needed Once, otherwise will get error TABLE already there
#cursor.execute("CREATE TABLE accounts (username VARCHAR(50), password VARCHAR(255))")


# The route() function of the Flask class is a decorator, 
# which tells the application which URL should call 
# the associated function.
@app.route('/hello')       
def hello(): 
    return 'HELLO'

@app.route('/')
@app.route('/login', methods =['GET', 'POST'])
def login():

   msg = ''
   if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
    username1 = request.form['username']
    password1 = request.form['password']
    

    cursor.execute('SELECT * FROM accounts WHERE username = %s AND password = %s', (username1, password1))
    account = cursor.fetchone()
    if account:
        print("logged In")
        session['loggedin'] = True
        
        session['0'] = username1
        msg = 'Logged in successfully !'
        return render_template('index.html', msg = msg)
    else:
        msg = 'Incorrect username / password !'
# TO keep login.html in templates folder, within crrent directory.https://stackoverflow.com/questions/23327293/flask-raises-templatenotfound-error-even-though-template-file-exists
# html code taken from https://dev.to/phylis/loginregistration-form-with-python-flask-and-mysql-3hek and pasted into login.html
#Google search how to implement registration flask python, then above link
    # 2factor authentication using google https://www.section.io/engineering-education/implementing-totp-2fa-using-flask/
   print("LAST CASE\n")
   return render_template("login.html",msg=msg)

@app.route('/register', methods =['GET', 'POST'])
def register():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username1 = request.form['username']
        password1 = request.form['password']
        #email = request.form['email']
        print(username1,password1)
        
        cursor.execute('SELECT * FROM accounts WHERE username = %s ',[username1])
        account = cursor.fetchone()
        if account:
            msg = 'Account already exists !'
        elif not re.match(r'[A-Za-z0-9]+', username1):
            msg = 'Username must contain only characters and numbers !'
        elif not username1 or not password1:
            msg = 'Please fill out the form !'
        else:
            cursor.execute( 'INSERT INTO accounts (username, password) VALUES (%s,%s)', (username1, password1) ) 
            mydb.commit()
            msg = 'You have successfully registered !'
    elif request.method == 'POST':
         msg = 'Please fill out the form !'
         print('Please fill out the form !')
    return render_template('register.html', msg = msg)
  
if __name__=='__main__': 
   app.run()